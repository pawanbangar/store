self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "eb55463d3e05a59231c499ec562363f8",
    "url": "/index.html"
  },
  {
    "revision": "189dfc9a07de447e59a4",
    "url": "/static/css/main.b45fbf9e.chunk.css"
  },
  {
    "revision": "0ca085eebcd029f412e2",
    "url": "/static/js/2.dd2e4c4c.chunk.js"
  },
  {
    "revision": "ad61e5a3703d8af976e070e9896b739a",
    "url": "/static/js/2.dd2e4c4c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "189dfc9a07de447e59a4",
    "url": "/static/js/main.dd7da5c0.chunk.js"
  },
  {
    "revision": "876f0d0bddc14466a705",
    "url": "/static/js/runtime-main.82a4823e.js"
  },
  {
    "revision": "ed28accb7dd58a0469bff983503ff07e",
    "url": "/static/media/crown.ed28accb.svg"
  },
  {
    "revision": "30f0707118fb960665491424c115ac44",
    "url": "/static/media/shopping-bag.30f07071.svg"
  }
]);